"""
AgroData CRM - Versión simplificada por consola
=================================================
Este código NO usa base de datos. Su único objetivo es mostrar,
con clases de Python, la estructura del diagrama UML de AgroData:

    - ABSTRACCIÓN       -> Usuario (ABC)
    - HERENCIA          -> Administrador, Gerente, Distribuidor heredan de Usuario
    - POLIMORFISMO      -> cada subclase de Usuario implementa permisos() distinto
    - ENCAPSULAMIENTO   -> atributos privados (__atributo) + getters/setters
    - ASOCIACIÓN        -> DetalleOrden conoce a Producto (colaboran, no lo contiene)
    - AGREGACIÓN        -> Distribuidor tiene Clientes, Cliente tiene Órdenes
                           (si se borra el distribuidor, el cliente sigue existiendo)
    - COMPOSICIÓN       -> Orden crea y posee sus propios DetalleOrden
                           (si se borra la orden, sus detalles desaparecen con ella)
"""

from abc import ABC, abstractmethod
from datetime import date


# ---------------------------------------------------------------------------
# ABSTRACCIÓN + HERENCIA: Usuario es la clase base de todos los roles
# ---------------------------------------------------------------------------
class Usuario(ABC):
    def __init__(self, id_usuario: int, nombres: str, apellidos: str):
        # Atributos privados -> ENCAPSULAMIENTO
        self.__id_usuario = id_usuario
        self.__nombres = nombres
        self.__apellidos = apellidos
        self.__estado_cuenta = "Activo"

    # Getters y setters
    def get_nombres(self) -> str:
        return self.__nombres

    def get_apellidos(self) -> str:
        return self.__apellidos

    def get_estado_cuenta(self) -> str:
        return self.__estado_cuenta

    def set_estado_cuenta(self, estado: str):
        self.__estado_cuenta = estado

    # Método obligatorio para todas las clases hijas -> POLIMORFISMO
    @abstractmethod
    def permisos(self) -> str:
        pass

    def mostrar_informacion(self):
        print(f"[{self.__class__.__name__}] {self.__nombres} {self.__apellidos} "
              f"(Estado: {self.__estado_cuenta})")
        print(f"   Permisos: {self.permisos()}")


class Administrador(Usuario):
    def permisos(self) -> str:
        return "Crear/editar/desactivar usuarios, asignar rol y zona"


class Gerente(Usuario):
    def permisos(self) -> str:
        return "Ver dashboard global, comparar distribuidores, exportar reportes"


class Distribuidor(Usuario):
    def __init__(self, id_usuario: int, nombres: str, apellidos: str):
        super().__init__(id_usuario, nombres, apellidos)
        self.__clientes = []  # AGREGACIÓN: el distribuidor "tiene" clientes

    def permisos(self) -> str:
        return "Crear clientes, registrar visitas, oportunidades y órdenes"

    def crear_cliente(self, cliente: "Cliente"):
        self.__clientes.append(cliente)
        print(f"   -> {self.get_nombres()} creó al cliente '{cliente.get_nombre_empresa()}'")

    def get_clientes(self):
        return self.__clientes


# ---------------------------------------------------------------------------
# Producto: clase simple, se relaciona por ASOCIACIÓN con DetalleOrden
# ---------------------------------------------------------------------------
class Producto:
    def __init__(self, nombre: str, categoria: str, unidad_medida: str):
        self.__nombre = nombre
        self.__categoria = categoria
        self.__unidad_medida = unidad_medida

    def get_nombre(self) -> str:
        return self.__nombre

    def get_unidad_medida(self) -> str:
        return self.__unidad_medida


# ---------------------------------------------------------------------------
# COMPOSICIÓN: DetalleOrden solo existe dentro de una Orden
# ---------------------------------------------------------------------------
class DetalleOrden:
    def __init__(self, producto: Producto, cantidad: int):
        self.__producto = producto  # ASOCIACIÓN: conoce al producto, no lo posee
        self.__cantidad = cantidad

    def get_cantidad(self) -> int:
        return self.__cantidad

    def mostrar(self):
        print(f"      - {self.__cantidad} {self.__producto.get_unidad_medida()} "
              f"de {self.__producto.get_nombre()}")


class Orden:
    def __init__(self, precio: float, fecha_entrega_acordada: date):
        self.__precio = precio
        self.__fecha_entrega_acordada = fecha_entrega_acordada
        self.__estado = "Pendiente"
        self.__detalles = []  # COMPOSICIÓN: la orden crea y posee sus detalles

    def agregar_producto(self, producto: Producto, cantidad: int):
        # La orden construye internamente sus propios DetalleOrden
        self.__detalles.append(DetalleOrden(producto, cantidad))

    def actualizar_estado(self, nuevo_estado: str):
        self.__estado = nuevo_estado

    def mostrar(self):
        print(f"   Orden por ${self.__precio:,.0f} - Estado: {self.__estado} "
              f"- Entrega: {self.__fecha_entrega_acordada}")
        for detalle in self.__detalles:
            detalle.mostrar()


# ---------------------------------------------------------------------------
# Oportunidad y Visita: registros ligados al cliente
# ---------------------------------------------------------------------------
class Oportunidad:
    def __init__(self, etapa: str, precio_pactado: float):
        self.__etapa = etapa
        self.__precio_pactado = precio_pactado
        self.__estado = "Abierta"

    def cambiar_etapa(self, nueva_etapa: str):
        self.__etapa = nueva_etapa
        print(f"   -> Oportunidad avanzó a la etapa: {nueva_etapa}")

    def cerrar(self, estado_final: str):
        self.__estado = estado_final

    def mostrar(self):
        print(f"   Oportunidad ({self.__etapa}) - ${self.__precio_pactado:,.0f} "
              f"- Estado: {self.__estado}")


class Visita:
    def __init__(self, fecha: date, objetivo: str):
        self.__fecha = fecha
        self.__objetivo = objetivo
        self.__notas_acuerdos = ""

    def registrar_resultado(self, notas: str):
        self.__notas_acuerdos = notas

    def mostrar(self):
        print(f"   Visita del {self.__fecha} - Objetivo: {self.__objetivo}")
        if self.__notas_acuerdos:
            print(f"      Acuerdos: {self.__notas_acuerdos}")


# ---------------------------------------------------------------------------
# Cliente: se relaciona por AGREGACIÓN con Orden, Oportunidad y Visita
# ---------------------------------------------------------------------------
class Cliente:
    def __init__(self, nombre_empresa: str, tipo_cliente: str, hectareas_aprox: float):
        self.__nombre_empresa = nombre_empresa
        self.__tipo_cliente = tipo_cliente
        self.__hectareas_aprox = hectareas_aprox
        self.__estado_cliente = "Activo"
        self.__ordenes = []        # AGREGACIÓN
        self.__oportunidades = []  # AGREGACIÓN
        self.__visitas = []        # AGREGACIÓN

    def get_nombre_empresa(self) -> str:
        return self.__nombre_empresa

    def registrar_orden(self, orden: Orden):
        self.__ordenes.append(orden)

    def registrar_oportunidad(self, oportunidad: Oportunidad):
        self.__oportunidades.append(oportunidad)

    def registrar_visita(self, visita: Visita):
        self.__visitas.append(visita)

    def mostrar_ficha(self):
        print(f"\nCliente: {self.__nombre_empresa} ({self.__tipo_cliente}) "
              f"- {self.__hectareas_aprox} ha - Estado: {self.__estado_cliente}")
        for visita in self.__visitas:
            visita.mostrar()
        for oportunidad in self.__oportunidades:
            oportunidad.mostrar()
        for orden in self.__ordenes:
            orden.mostrar()


# ---------------------------------------------------------------------------
# PROGRAMA PRINCIPAL (simula el flujo real del CRM por consola)
# ---------------------------------------------------------------------------
def main():
    print("=" * 60)
    print(" DEMO AGRODATA CRM - ESTRUCTURA DE CLASES (POO)")
    print("=" * 60)

    # --- Usuarios (herencia + polimorfismo) ---
    print("\n--- Usuarios del sistema ---")
    admin = Administrador(1, "Karol", "Delgado")
    gerente = Gerente(2, "Juan", "Nieto")
    distribuidor = Distribuidor(3, "Camilo", "Cetina")

    for usuario in (admin, gerente, distribuidor):
        usuario.mostrar_informacion()  # mismo método, distinta salida -> POLIMORFISMO

    # --- Distribuidor crea un cliente (agregación) ---
    print("\n--- Gestión comercial ---")
    cliente = Cliente("Finca La Esperanza", "Agricultor", 35.5)
    distribuidor.crear_cliente(cliente)

    # --- Productos (independientes) ---
    fertilizante = Producto("Fertilizante NPK", "Fertilizantes", "Bulto 50kg")
    fungicida = Producto("Fungicida X", "Agroquímicos", "Litro")

    # --- Visita ---
    visita = Visita(date.today(), "Presentar catálogo de productos")
    visita.registrar_resultado("Cliente interesado en fertilizante NPK")
    cliente.registrar_visita(visita)

    # --- Oportunidad ---
    oportunidad = Oportunidad("Negociación", 2_500_000)
    oportunidad.cambiar_etapa("Cierre")
    cliente.registrar_oportunidad(oportunidad)

    # --- Orden con detalles (composición) ---
    orden = Orden(2_500_000, date(2026, 9, 25))
    orden.agregar_producto(fertilizante, 10)
    orden.agregar_producto(fungicida, 5)
    orden.actualizar_estado("Confirmada")
    cliente.registrar_orden(orden)

    # --- Resultado final ---
    print("\n--- Ficha completa del cliente ---")
    cliente.mostrar_ficha()


if __name__ == "__main__":
    main()
