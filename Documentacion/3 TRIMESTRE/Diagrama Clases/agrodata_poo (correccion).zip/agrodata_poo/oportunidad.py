class Oportunidad:
    def __init__(self, etapa: str, precio_pactado: float):
        self.__etapa = etapa
        self.__precio_pactado = precio_pactado
        self.__estado = "Abierta"

    def cambiar_etapa(self, nueva_etapa: str):
        self.__etapa = nueva_etapa
        print(f"   -> Oportunidad avanzó a la etapa: {nueva_etapa}")

    def cerrar(self, estado_final: str):
        self.__estado = estado_final

    def mostrar(self):
        print(f"   Oportunidad ({self.__etapa}) - ${self.__precio_pactado:,.0f} "
              f"- Estado: {self.__estado}")
