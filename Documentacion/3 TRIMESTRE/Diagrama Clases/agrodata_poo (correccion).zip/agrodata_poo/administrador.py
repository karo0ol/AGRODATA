from usuario import Usuario


class Administrador(Usuario):
    def permisos(self) -> str:
        return "Crear/editar/desactivar usuarios, asignar rol y zona"
