from producto import Producto


class DetalleOrden:
    def __init__(self, producto: Producto, cantidad: int):
        self.__producto = producto  # ASOCIACIÓN: conoce al producto, no lo posee
        self.__cantidad = cantidad

    def get_cantidad(self) -> int:
        return self.__cantidad

    def mostrar(self):
        print(f"      - {self.__cantidad} {self.__producto.get_unidad_medida()} "
              f"de {self.__producto.get_nombre()}")
