class Producto:
    def __init__(self, nombre: str, categoria: str, unidad_medida: str):
        self.__nombre = nombre
        self.__categoria = categoria
        self.__unidad_medida = unidad_medida

    def get_nombre(self) -> str:
        return self.__nombre

    def get_unidad_medida(self) -> str:
        return self.__unidad_medida
