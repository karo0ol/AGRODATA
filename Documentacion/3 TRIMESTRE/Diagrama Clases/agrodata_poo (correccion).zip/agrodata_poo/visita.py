from datetime import date


class Visita:
    def __init__(self, fecha: date, objetivo: str):
        self.__fecha = fecha
        self.__objetivo = objetivo
        self.__notas_acuerdos = ""

    def registrar_resultado(self, notas: str):
        self.__notas_acuerdos = notas

    def mostrar(self):
        print(f"   Visita del {self.__fecha} - Objetivo: {self.__objetivo}")
        if self.__notas_acuerdos:
            print(f"      Acuerdos: {self.__notas_acuerdos}")
