from usuario import Usuario


class Gerente(Usuario):
    def permisos(self) -> str:
        return "Ver dashboard global, comparar distribuidores, exportar reportes"
