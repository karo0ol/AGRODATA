"""
AgroData CRM - Demo por consola
================================
Cada clase del diagrama vive en su propio archivo (igual que en el
material de clase: persona.py, propietario.py, veterinario.py...).
Este archivo solo importa las clases y arma el flujo de ejemplo.
"""

from datetime import date

from administrador import Administrador
from gerente import Gerente
from distribuidor import Distribuidor
from cliente import Cliente
from producto import Producto
from visita import Visita
from oportunidad import Oportunidad
from orden import Orden


def main():
    print("=" * 60)
    print(" DEMO AGRODATA CRM - ESTRUCTURA DE CLASES (POO)")
    print("=" * 60)

    # --- Usuarios (herencia + polimorfismo) ---
    print("\n--- Usuarios del sistema ---")
    admin = Administrador(1, "Karol", "Delgado")
    gerente = Gerente(2, "Juan", "Nieto")
    distribuidor = Distribuidor(3, "Camilo", "Cetina")

    for usuario in (admin, gerente, distribuidor):
        usuario.mostrar_informacion()  # mismo método, distinta salida -> POLIMORFISMO

    # --- Distribuidor crea un cliente (agregación) ---
    print("\n--- Gestión comercial ---")
    cliente = Cliente("Finca La Esperanza", "Agricultor", 35.5)
    distribuidor.crear_cliente(cliente)

    # --- Productos (independientes) ---
    fertilizante = Producto("Fertilizante NPK", "Fertilizantes", "Bulto 50kg")
    fungicida = Producto("Fungicida X", "Agroquímicos", "Litro")

    # --- Visita ---
    visita = Visita(date.today(), "Presentar catálogo de productos")
    visita.registrar_resultado("Cliente interesado en fertilizante NPK")
    cliente.registrar_visita(visita)

    # --- Oportunidad ---
    oportunidad = Oportunidad("Negociación", 2_500_000)
    oportunidad.cambiar_etapa("Cierre")
    cliente.registrar_oportunidad(oportunidad)

    # --- Orden con detalles (composición) ---
    orden = Orden(2_500_000, date(2026, 9, 25))
    orden.agregar_producto(fertilizante, 10)
    orden.agregar_producto(fungicida, 5)
    orden.actualizar_estado("Confirmada")
    cliente.registrar_orden(orden)

    # --- Resultado final ---
    print("\n--- Ficha completa del cliente ---")
    cliente.mostrar_ficha()


if __name__ == "__main__":
    main()
