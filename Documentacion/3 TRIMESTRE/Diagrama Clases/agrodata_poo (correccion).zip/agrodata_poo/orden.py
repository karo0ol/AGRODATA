from datetime import date
from producto import Producto
from detalle_orden import DetalleOrden


class Orden:
    def __init__(self, precio: float, fecha_entrega_acordada: date):
        self.__precio = precio
        self.__fecha_entrega_acordada = fecha_entrega_acordada
        self.__estado = "Pendiente"
        self.__detalles = []  # COMPOSICIÓN: la orden crea y posee sus detalles

    def agregar_producto(self, producto: Producto, cantidad: int):
        # La orden construye internamente sus propios DetalleOrden
        self.__detalles.append(DetalleOrden(producto, cantidad))

    def actualizar_estado(self, nuevo_estado: str):
        self.__estado = nuevo_estado

    def mostrar(self):
        print(f"   Orden por ${self.__precio:,.0f} - Estado: {self.__estado} "
              f"- Entrega: {self.__fecha_entrega_acordada}")
        for detalle in self.__detalles:
            detalle.mostrar()
