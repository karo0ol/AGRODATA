from orden import Orden
from oportunidad import Oportunidad
from visita import Visita


class Cliente:
    def __init__(self, nombre_empresa: str, tipo_cliente: str, hectareas_aprox: float):
        self.__nombre_empresa = nombre_empresa
        self.__tipo_cliente = tipo_cliente
        self.__hectareas_aprox = hectareas_aprox
        self.__estado_cliente = "Activo"
        self.__ordenes = []        # AGREGACIÓN
        self.__oportunidades = []  # AGREGACIÓN
        self.__visitas = []        # AGREGACIÓN

    def get_nombre_empresa(self) -> str:
        return self.__nombre_empresa

    def registrar_orden(self, orden: Orden):
        self.__ordenes.append(orden)

    def registrar_oportunidad(self, oportunidad: Oportunidad):
        self.__oportunidades.append(oportunidad)

    def registrar_visita(self, visita: Visita):
        self.__visitas.append(visita)

    def mostrar_ficha(self):
        print(f"\nCliente: {self.__nombre_empresa} ({self.__tipo_cliente}) "
              f"- {self.__hectareas_aprox} ha - Estado: {self.__estado_cliente}")
        for visita in self.__visitas:
            visita.mostrar()
        for oportunidad in self.__oportunidades:
            oportunidad.mostrar()
        for orden in self.__ordenes:
            orden.mostrar()
