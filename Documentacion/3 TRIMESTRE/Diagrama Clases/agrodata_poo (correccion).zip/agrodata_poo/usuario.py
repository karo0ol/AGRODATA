"""
Usuario (ABC)
-------------
Clase base abstracta para todos los roles del sistema.
No se puede instanciar directamente: Administrador, Gerente y
Distribuidor deben heredar de ella e implementar permisos().
"""

from abc import ABC, abstractmethod


class Usuario(ABC):
    def __init__(self, id_usuario: int, nombres: str, apellidos: str):
        # Atributos privados -> ENCAPSULAMIENTO
        self.__id_usuario = id_usuario
        self.__nombres = nombres
        self.__apellidos = apellidos
        self.__estado_cuenta = "Activo"

    def get_nombres(self) -> str:
        return self.__nombres

    def get_apellidos(self) -> str:
        return self.__apellidos

    def get_estado_cuenta(self) -> str:
        return self.__estado_cuenta

    def set_estado_cuenta(self, estado: str):
        self.__estado_cuenta = estado

    @abstractmethod
    def permisos(self) -> str:
        """Cada rol define sus propios permisos -> POLIMORFISMO"""
        pass

    def mostrar_informacion(self):
        print(f"[{self.__class__.__name__}] {self.__nombres} {self.__apellidos} "
              f"(Estado: {self.__estado_cuenta})")
        print(f"   Permisos: {self.permisos()}")
