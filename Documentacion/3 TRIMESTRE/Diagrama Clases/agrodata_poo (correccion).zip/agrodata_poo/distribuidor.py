from usuario import Usuario


class Distribuidor(Usuario):
    def __init__(self, id_usuario: int, nombres: str, apellidos: str):
        super().__init__(id_usuario, nombres, apellidos)
        self.__clientes = []  # AGREGACIÓN: el distribuidor "tiene" clientes

    def permisos(self) -> str:
        return "Crear clientes, registrar visitas, oportunidades y órdenes"

    def crear_cliente(self, cliente):
        self.__clientes.append(cliente)
        print(f"   -> {self.get_nombres()} creó al cliente '{cliente.get_nombre_empresa()}'")

    def get_clientes(self):
        return self.__clientes
